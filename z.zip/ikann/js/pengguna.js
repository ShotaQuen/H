let number = localStorage.getItem('number') ? parseInt(localStorage.getItem('number')) : 0;

        // Menampilkan angka yang tersimpan
        document.getElementById('numberDisplay').textContent = number;

        // Fungsi untuk menambah angka hanya sekali
        function incrementNumber() {
            // Cek jika angka sudah bertambah sebelumnya
            if (localStorage.getItem('numberAdded')) {
                
                
                return;
            }

            // Menambah angka dan menyimpannya
            number++;
            localStorage.setItem('number', number);
            localStorage.setItem('numberAdded', 'true');  // Tandai bahwa angka sudah ditambah

            // Memperbarui tampilan angka
            document.getElementById('numberDisplay').textContent = number;
        }