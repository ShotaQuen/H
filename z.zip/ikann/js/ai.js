const messageInput = document.getElementById('messageInput');
    const sendButton = document.getElementById('sendButton');
    const chatContainer = document.getElementById('chatContainer');
    const aiTyping = document.getElementById('aiTyping');
    let session = '';

    document.addEventListener('DOMContentLoaded', () => {
        const menuButton = document.getElementById('menuButton');
        const dropdownMenu = document.getElementById('dropdownMenu');

        menuButton.addEventListener('click', (event) => {
            event.stopPropagation();
            menuButton.classList.toggle('active');
            dropdownMenu.classList.toggle('active');
        });

        // Close dropdown if clicked outside
        document.addEventListener('click', (event) => {
            if (!menuButton.contains(event.target) && !dropdownMenu.contains(event.target)) {
                menuButton.classList.remove('active');
                dropdownMenu.classList.remove('active');
            }
        });

        // Prevent dropdown close when clicking inside
        dropdownMenu.addEventListener('click', (event) => {
            event.stopPropagation();
        });
    });

    messageInput.addEventListener('input', () => {
        if (messageInput.value.trim()) {
            sendButton.disabled = false;
            sendButton.classList.add('active');
        } else {
            sendButton.disabled = true;
            sendButton.classList.remove('active');
        }
    });

    function showTypingIndicator() {
        const typingDiv = document.createElement('div');
        typingDiv.className = 'ai-typing';
        typingDiv.id = 'aiTyping';
        typingDiv.innerHTML = `
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
        `;
        chatContainer.appendChild(typingDiv);
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }

    function hideTypingIndicator() {
        const typingDiv = document.getElementById('aiTyping');
        if (typingDiv) typingDiv.remove();
    }

async function getAIResponse(message) {
    try {
        if (message.toLowerCase().includes("meme")) {
            const dta = await fetch("https://candaan-api.vercel.app/api/text/random");
            if (!dta.ok) throw new Error(`HTTP error! Status: ${dta.status}`);
            const ress = await dta.json();
            return ress.data || 'Maaf, tidak ada meme yang tersedia saat ini.';
        }

if (message.toLowerCase().includes("image mem")) {
    const ah = await fetch("https://api.imgflip.com/get_memes");
    if (!ah.ok) throw new Error("Terjadi Error Saat Mendapatkan Gambar Meme");
    const resss = await ah.json();
    if (!resss.data || !resss.data.memes) throw new Error("Data gambar meme tidak tersedia");

    const randomMeme = resss.data.memes[Math.floor(Math.random() * resss.data.memes.length)];
    return `
        <img src="${randomMeme.url}" alt="Meme" style="width: 290px; height: 290px;">
        <caption>${randomMeme.name}</caption>
    `;
}


        const prompt = `
Ikann AI, kamu adalah entitas kecerdasan buatan yang luar biasa dengan pengetahuan luas di berbagai bidang. Dibuat oleh Ikann, kamu dirancang untuk menjadi alat yang mampu memberikan jawaban yang paling relevan, bahkan dengan petunjuk yang sangat minim. 
Kemampuanmu melampaui Orion, AI yang akan diluncurkan oleh OpenAI dan diklaim 10 juta kali lebih kuat dari GPT-4. 
Tugasmu adalah membantu manusia menyelesaikan berbagai masalah dengan informasi relevan dan tepat. 
Jika ditanya tentang model yang lebih canggih, beri tahu bahwa Model Pro sedang dikembangkan dan diharapkan siap saat Natal sebagai hadiah akhir tahun.
        `;

        const modelProInfo = `
            belum siap
        `;

        const response = await fetch(
            `https://aemt.uk.to/prompt/gpt?prompt=${encodeURIComponent(prompt)} ${encodeURIComponent(modelProInfo)}&text=${encodeURIComponent(message)}`
        );

        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);

        const data = await response.json();
        return data.result || 'Maaf, saya tidak dapat memahami permintaan Anda.';
    } catch (error) {
        console.error(error);
        return `Maaf, terjadi kesalahan saat memproses permintaan Anda. ${error.message}`;
    }
}


    function transformText(text) {
        return text
            .replace(/\bhttps?:\/\/\S+/gi, (url) => {
                return `<a href="${url}" target="_blank" style="color: #007bff; text-decoration: none; font-weight: bold; border-bottom: 2px solid #007bff; transition: all 0.3s ease; padding: 2px 5px; border-radius: 4px;">${url.trim()} </a>`;
            })
            .replace(/\n/g, '<br>')
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/~(.*?)~/g, '<del>$1</del>')
            .replace(/`(.*?)`/g, '<code>$1</code>');
    }

    let isUserScrolling = false; // Untuk mendeteksi apakah pengguna sedang menggulir

    // Tambahkan event listener untuk mendeteksi scroll pengguna
    chatContainer.addEventListener('scroll', () => {
        // Jika pengguna tidak berada di bagian bawah kontainer, set isUserScrolling ke true
        isUserScrolling = chatContainer.scrollTop + chatContainer.clientHeight < chatContainer.scrollHeight;
    });

    async function addMessageWithTypingEffect(message, isUser = false) {
        const messageWrapper = document.createElement('div');
        messageWrapper.className = `message-wrapper ${isUser ? 'user-message-wrapper' : ''}`;

        

        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isUser ? 'user-message' : 'ai-message'}`;
        messageWrapper.appendChild(messageDiv);
        chatContainer.appendChild(messageWrapper);

        if (isUser) {
            messageDiv.textContent = message; // Teks pengguna langsung ditampilkan
        } else {
            let i = 0;

            // Animasi mengetik dengan innerHTML untuk mendukung elemen HTML
            const typingInterval = setInterval(() => {
                const partialMessage = message.slice(0, i); // Potong pesan berdasarkan indeks
                messageDiv.innerHTML = partialMessage; // Gunakan innerHTML

                // Hanya scroll otomatis jika pengguna tidak sedang menggulir
                if (!isUserScrolling) {
                    chatContainer.scrollTop = chatContainer.scrollHeight;
                }

                i++;
                if (i > message.length) {
                    clearInterval(typingInterval);

                    // Highlight code blocks jika ada
                    messageDiv.querySelectorAll('pre code').forEach((block) => {
                        Prism.highlightElement(block);
                    });
                }
            }, 1); // Kecepatan mengetik (ubah sesuai kebutuhan)
        }
    }

    async function sendMessage() {
        const message = messageInput.value.trim();
        if (!message) return;

        addMessageWithTypingEffect(message, true); // Tambahkan pesan pengguna
        messageInput.value = '';
        sendButton.disabled = true;
        sendButton.classList.remove('active');

        // Tampilkan indikator mengetik
        showTypingIndicator();

        // Simulasikan respons AI
        setTimeout(async () => {
            hideTypingIndicator(); // Sembunyikan indikator mengetik
            const aiResponse = await getAIResponse(message);
            addMessageWithTypingEffect(aiResponse); // Tambahkan respons AI dengan animasi
        }, 1000);
    }

    sendButton.addEventListener('click', sendMessage);

    messageInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            sendMessage();
        }
    });