function updateTime() {
const now = new Date();

// Mendapatkan nama hari
const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
const dayName = days[now.getDay()];

// Mendapatkan tanggal, bulan, dan tahun
const date = now.getDate();
const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
const monthName = months[now.getMonth()];
const year = now.getFullYear();

// Mendapatkan waktu
const hours = String(now.getHours()).padStart(2, '0');
const minutes = String(now.getMinutes()).padStart(2, '0');
const seconds = String(now.getSeconds()).padStart(2, '0');

// Menampilkan ke elemen HTML
document.getElementById('all').innerText = `${dayName} / ${date} / ${monthName} / ${year}`;
}

// Update setiap detik
setInterval(updateTime, 1000);

// Panggil fungsi saat pertama kali halaman dimuat
updateTime();